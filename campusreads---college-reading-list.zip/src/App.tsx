/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  Bookmark,
  Library,
  Sparkles,
  Search,
  BookCheck,
  ChevronDown,
  AlertCircle,
} from 'lucide-react';

export type BookStatus = 'To Read' | 'Reading' | 'Done';

export interface Book {
  id: string;
  title: string;
  status: BookStatus;
  createdAt: number;
}

const INITIAL_BOOKS: Book[] = [
  {
    id: 'book-1',
    title: 'Introduction to Algorithms (CLRS)',
    status: 'Reading',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  },
  {
    id: 'book-2',
    title: 'The Design of Everyday Things',
    status: 'To Read',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  },
  {
    id: 'book-3',
    title: 'Sapiens: A Brief History of Humankind',
    status: 'Done',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  },
];

const STORAGE_KEY = 'campus_reads_books_v1';

export default function App() {
  const [books, setBooks] = useState<Book[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved !== null) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback on error
    }
    return INITIAL_BOOKS;
  });

  const [newTitle, setNewTitle] = useState('');
  const [newStatus, setNewStatus] = useState<BookStatus>('To Read');
  const [activeFilter, setActiveFilter] = useState<'All' | BookStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [inputError, setInputError] = useState('');

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    } catch {
      // Handle storage quotas or privacy mode
    }
  }, [books]);

  // Counts
  const counts = {
    all: books.length,
    toRead: books.filter((b) => b.status === 'To Read').length,
    reading: books.filter((b) => b.status === 'Reading').length,
    done: books.filter((b) => b.status === 'Done').length,
  };

  const handleAddBook = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTitle.trim();
    if (!trimmed) {
      setInputError('Please enter a book title');
      return;
    }

    const isDuplicate = books.some(
      (book) => book.title.trim().toLowerCase() === trimmed.toLowerCase()
    );
    if (isDuplicate) {
      setInputError('name already taken');
      return;
    }

    const newBook: Book = {
      id: 'book-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      title: trimmed,
      status: newStatus,
      createdAt: Date.now(),
    };

    setBooks([newBook, ...books]);
    setNewTitle('');
    setInputError('');
  };

  const handleStatusChange = (id: string, newStatus: BookStatus) => {
    setBooks(
      books.map((book) => (book.id === id ? { ...book, status: newStatus } : book))
    );
  };

  const handleDeleteBook = (id: string) => {
    setBooks(books.filter((book) => book.id !== id));
  };

  const handleResetSampleBooks = () => {
    setBooks(INITIAL_BOOKS);
    setActiveFilter('All');
  };

  const handleClearAll = () => {
    setBooks([]);
  };

  // Filtered books
  const filteredBooks = books.filter((book) => {
    const matchesFilter = activeFilter === 'All' || book.status === activeFilter;
    const matchesSearch = book.title
      .toLowerCase()
      .includes(searchQuery.toLowerCase().trim());
    return matchesFilter && matchesSearch;
  });

  // Status badge styling helper
  const getStatusBadgeStyle = (status: BookStatus) => {
    switch (status) {
      case 'To Read':
        return {
          badge: 'bg-amber-50 text-amber-800 border-amber-200 ring-1 ring-amber-500/10',
          dot: 'bg-amber-500',
          icon: Clock,
          label: 'To Read',
        };
      case 'Reading':
        return {
          badge: 'bg-blue-50 text-blue-800 border-blue-200 ring-1 ring-blue-500/10',
          dot: 'bg-blue-500',
          icon: BookOpen,
          label: 'Reading',
        };
      case 'Done':
        return {
          badge: 'bg-emerald-50 text-emerald-800 border-emerald-200 ring-1 ring-emerald-500/10',
          dot: 'bg-emerald-500',
          icon: CheckCircle2,
          label: 'Done',
        };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 antialiased font-sans">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Library className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
                CampusReads
              </h1>
              <p className="text-xs text-slate-500 hidden sm:block">
                College Student Reading List Tracker
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {books.length > 0 ? (
              <button
                type="button"
                onClick={handleClearAll}
                className="text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-red-600 hover:border-red-200 hover:bg-red-50 transition-colors"
                title="Clear all books to test empty state"
              >
                Clear all
              </button>
            ) : (
              <button
                type="button"
                onClick={handleResetSampleBooks}
                className="text-xs font-medium px-3 py-1.5 rounded-lg border border-indigo-200 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 transition-colors flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Load sample books
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Intro Banner for students */}
        <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-violet-700 rounded-2xl p-5 sm:p-6 text-white shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-white/15 text-indigo-100 mb-2 border border-white/10">
                <Bookmark className="w-3 h-3" /> Semester Study & Leisure Reads
              </span>
              <h2 className="text-xl sm:text-2xl font-bold">
                Keep track of every book on your syllabus
              </h2>
              <p className="text-sm text-indigo-100/90 mt-1 max-w-xl">
                Organize textbooks, research literature, and leisure reading. Fast,
                private, and stored right in your browser.
              </p>
            </div>
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-xl border border-white/15 self-start sm:self-auto shrink-0">
              <div className="text-center">
                <div className="text-2xl font-extrabold">{counts.all}</div>
                <div className="text-[10px] uppercase font-semibold tracking-wider text-indigo-200">
                  Total Books
                </div>
              </div>
              <div className="w-px h-8 bg-white/20" />
              <div className="text-center">
                <div className="text-2xl font-extrabold text-emerald-300">
                  {counts.done}
                </div>
                <div className="text-[10px] uppercase font-semibold tracking-wider text-indigo-200">
                  Finished
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 1. Add Book Form */}
        <section aria-labelledby="add-book-heading" className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 id="add-book-heading" className="text-base font-semibold text-slate-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-600" />
              Add a Book
            </h2>
            <span className="text-xs text-slate-400">Step 1: Enter title & select status</span>
          </div>

          <form onSubmit={handleAddBook} className="space-y-3 sm:space-y-0 sm:flex sm:gap-3">
            <div className="flex-1">
              <label htmlFor="book-title" className="sr-only">
                Book Title
              </label>
              <input
                id="book-title"
                type="text"
                placeholder="e.g. Machine Learning Yearning, or To Kill a Mockingbird"
                value={newTitle}
                onChange={(e) => {
                  setNewTitle(e.target.value);
                  if (inputError) setInputError('');
                }}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm transition-all focus:outline-none focus:ring-2 ${
                  inputError
                    ? 'border-red-400 focus:border-red-500 focus:ring-red-200'
                    : 'border-slate-300 focus:border-indigo-500 focus:ring-indigo-100 hover:border-slate-400'
                }`}
              />
              {inputError && (
                <p role="alert" className="text-xs text-red-600 mt-1.5 ml-1 font-medium flex items-center gap-1.5 animate-fadeIn">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{inputError}</span>
                </p>
              )}
            </div>

            <div className="w-full sm:w-44">
              <label htmlFor="book-status" className="sr-only">
                Status
              </label>
              <div className="relative">
                <select
                  id="book-status"
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as BookStatus)}
                  className="w-full appearance-none px-4 py-2.5 pr-10 rounded-xl border border-slate-300 text-sm font-medium text-slate-700 bg-white hover:border-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 transition-all cursor-pointer"
                >
                  <option value="To Read">To Read</option>
                  <option value="Reading">Reading</option>
                  <option value="Done">Done</option>
                </select>
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <ChevronDown className="w-4 h-4" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-medium text-sm transition-colors shadow-xs flex items-center justify-center gap-2 shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Book</span>
            </button>
          </form>
        </section>

        {/* 2 & 3. Filters & Status Counts */}
        <section aria-labelledby="reading-list-heading" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 id="reading-list-heading" className="text-lg font-bold text-slate-900">
                Your Reading List
              </h2>
              <p className="text-xs text-slate-500">
                Filter by status or switch a book&apos;s status at any time
              </p>
            </div>

            {/* Optional search input */}
            {books.length > 0 && (
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search books..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            )}
          </div>

          {/* Filter Tabs with Counts */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-200/60 rounded-xl border border-slate-200">
            {/* All Filter */}
            <button
              type="button"
              onClick={() => setActiveFilter('All')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeFilter === 'All'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <span>All</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[11px] ${
                  activeFilter === 'All'
                    ? 'bg-slate-900 text-white font-bold'
                    : 'bg-slate-300 text-slate-700'
                }`}
              >
                {counts.all}
              </span>
            </button>

            {/* To Read Filter */}
            <button
              type="button"
              onClick={() => setActiveFilter('To Read')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeFilter === 'To Read'
                  ? 'bg-white text-amber-800 shadow-xs'
                  : 'text-slate-600 hover:text-amber-800 hover:bg-slate-200/50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>To Read</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[11px] ${
                  activeFilter === 'To Read'
                    ? 'bg-amber-600 text-white font-bold'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {counts.toRead}
              </span>
            </button>

            {/* Reading Filter */}
            <button
              type="button"
              onClick={() => setActiveFilter('Reading')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeFilter === 'Reading'
                  ? 'bg-white text-blue-800 shadow-xs'
                  : 'text-slate-600 hover:text-blue-800 hover:bg-slate-200/50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <span>Reading</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[11px] ${
                  activeFilter === 'Reading'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-blue-100 text-blue-800'
                }`}
              >
                {counts.reading}
              </span>
            </button>

            {/* Done Filter */}
            <button
              type="button"
              onClick={() => setActiveFilter('Done')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeFilter === 'Done'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-emerald-800 hover:bg-slate-200/50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Done</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[11px] ${
                  activeFilter === 'Done'
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {counts.done}
              </span>
            </button>
          </div>

          {/* Book Cards Display */}
          {books.length === 0 ? (
            /* Explicit Empty state required by prompt:
               "when there are no books, show the message "No books yet. Add your first book." with the add form visible." */
            <div className="bg-white rounded-2xl border-2 border-dashed border-slate-300 p-8 sm:p-12 text-center shadow-xs">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mb-4">
                <BookOpen className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-1">
                No books yet. Add your first book.
              </h3>
              <p className="text-sm text-slate-500 max-w-sm mx-auto mb-6">
                Use the form above to add a textbook, paper, or novel you want to
                tackle this term.
              </p>
              <button
                type="button"
                onClick={handleResetSampleBooks}
                className="inline-flex items-center gap-2 text-xs font-medium px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                Or load 3 sample books
              </button>
            </div>
          ) : filteredBooks.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center shadow-xs">
              <p className="text-sm font-medium text-slate-600 mb-2">
                No books found matching &quot;{activeFilter}&quot;
                {searchQuery ? ` and &quot;${searchQuery}&quot;` : ''}.
              </p>
              <button
                type="button"
                onClick={() => {
                  setActiveFilter('All');
                  setSearchQuery('');
                }}
                className="text-xs font-semibold text-indigo-600 hover:underline"
              >
                Reset filters
              </button>
            </div>
          ) : (
            /* List of Cards: responsive grid (1 col on mobile, 2 or 3 cols on tablet/desktop) */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredBooks.map((book) => {
                const badgeInfo = getStatusBadgeStyle(book.status);
                const BadgeIcon = badgeInfo.icon;

                return (
                  <div
                    key={book.id}
                    className="bg-white rounded-2xl p-5 border border-slate-200/90 hover:border-slate-300 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Status Badge + Delete Action */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${badgeInfo.badge}`}
                        >
                          <BadgeIcon className="w-3.5 h-3.5" />
                          <span>{badgeInfo.label}</span>
                        </span>

                        <button
                          type="button"
                          onClick={() => handleDeleteBook(book.id)}
                          className="opacity-60 group-hover:opacity-100 hover:text-red-600 p-1 rounded-lg text-slate-400 hover:bg-red-50 transition-colors"
                          title="Delete book"
                          aria-label={`Delete ${book.title}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Book Title */}
                      <h3 className="text-base font-semibold text-slate-900 leading-snug line-clamp-3 mb-2">
                        {book.title}
                      </h3>
                    </div>

                    {/* Change Status Control */}
                    <div className="pt-4 mt-3 border-t border-slate-100">
                      <label
                        htmlFor={`status-select-${book.id}`}
                        className="text-[11px] font-medium text-slate-400 block mb-1.5"
                      >
                        Change Status:
                      </label>
                      <div className="relative">
                        <select
                          id={`status-select-${book.id}`}
                          value={book.status}
                          onChange={(e) =>
                            handleStatusChange(book.id, e.target.value as BookStatus)
                          }
                          className="w-full text-xs font-medium py-1.5 px-2.5 pr-8 rounded-lg border border-slate-200 bg-slate-50/80 text-slate-700 hover:bg-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-colors cursor-pointer appearance-none"
                        >
                          <option value="To Read">To Read</option>
                          <option value="Reading">Reading</option>
                          <option value="Done">Done</option>
                        </select>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Quick summary stats footer */}
        <footer className="pt-4 pb-8 border-t border-slate-200 text-center text-xs text-slate-500 space-y-2">
          <p className="flex items-center justify-center gap-1.5">
            <BookCheck className="w-4 h-4 text-emerald-600" />
            <span>
              All book tracking data is safely saved in your browser&apos;s local storage.
            </span>
          </p>
          <p className="text-[11px] text-slate-400">
            CampusReads • Built for college students & lifelong learners
          </p>
        </footer>
      </main>
    </div>
  );
}
